create function test_function() returns void
    language plpgsql
as
$$

begin
    raise notice 'test_function() called';
--     raise exception 'test_function() called';

end;
$$;

alter function test_function() owner to postgres;

