create function test_function2(name_arg text)
    returns TABLE(id bigint, name character varying)
    language plpgsql
as
$$

begin
    update app_user au
    set name = name_arg
    where au.id = 1;
    return query
        select au.id, au.name from app_user au;

end;
$$;

alter function test_function2(text) owner to postgres;

